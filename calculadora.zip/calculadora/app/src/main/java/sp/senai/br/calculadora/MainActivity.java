package sp.senai.br.calculadora;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etVr1, etVr2;
    TextView tvResultado;
    ConstraintLayout clPrincipal;
    Button btnMais, btnMenos, btnMult, btnDiv, btnLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etVr1 = findViewById(R.id.etVr1);
        etVr2 = findViewById(R.id.etVr2);
        tvResultado = findViewById(R.id.tvResultado);
        clPrincipal = findViewById(R.id.clPrincipal);
        btnMais = findViewById(R.id.btnMais);
        btnMenos = findViewById(R.id.btnMenos);
        btnMult = findViewById(R.id.btnMult);
        btnDiv = findViewById(R.id.btnDiv);
        btnLimpar = findViewById(R.id.btnLimpar);
        limpeza();

    }

    public void mais(View m){
        float fVr1 = Float.parseFloat(etVr1.getText().toString());
        float fVr2 = Float.parseFloat(etVr2.getText().toString());
        tvResultado.setText(String.valueOf(fVr1+fVr2));
        habilita(false);
        definecor(fVr1+fVr2);
    }
    public void menos(View m){
        float fVr1 = Float.parseFloat(etVr1.getText().toString());
        float fVr2 = Float.parseFloat(etVr2.getText().toString());
        tvResultado.setText(String.valueOf(fVr1-fVr2));
        habilita(false);
        definecor(fVr1-fVr2);
    }
    public void multiplicacao(View m){
        float fVr1 = Float.parseFloat(etVr1.getText().toString());
        float fVr2 = Float.parseFloat(etVr2.getText().toString());
        tvResultado.setText(String.valueOf(fVr1*fVr2));
        habilita(false);
    }
    public void divisao(View d){
        float fVr1 = Float.parseFloat(etVr1.getText().toString());
        float fVr2 = Float.parseFloat(etVr2.getText().toString());
        tvResultado.setText(String.valueOf(fVr1/fVr2));
        habilita(false);
    }
    public void limpar(View l){
        limpeza();
    }
    public void habilita(boolean lFaz){
        etVr1.setEnabled(lFaz); //desabilita a digitação
        etVr2.setEnabled(lFaz);
        btnMais.setEnabled(lFaz);
        btnMenos.setEnabled(lFaz);
        btnMult.setEnabled(lFaz);
        btnDiv.setEnabled(lFaz);
        btnLimpar.setEnabled(!lFaz);
    }
    public void limpeza(){
        etVr1.setText(null);
        etVr2.setText(null);
        tvResultado.setText(null);
        etVr1.requestFocus();
        habilita(true);
        clPrincipal.setBackgroundColor(Color.parseColor("#FFFFFF"));
        tvResultado.setTextColor(Color.parseColor("#000000"));

    }
    public void definecor(float conta){
        if ((conta)>0){
            clPrincipal.setBackgroundColor(Color.parseColor("#8ACE00"));
            tvResultado.setTextColor(Color.parseColor("#000000"));
        }else{
            clPrincipal.setBackgroundColor(Color.parseColor("#FA0000"));
            tvResultado.setTextColor(Color.parseColor("#000000"));
        }
    }
}
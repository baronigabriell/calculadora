package sp.senai.br.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etNota1, etNota2;
    TextView tvSituacao, tvMedia;
    ConstraintLayout clPrincipal;
    Button btnCalcular, btnLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        tvSituacao = findViewById(R.id.tvSituacao);
        tvMedia = findViewById(R.id.tvMedia);
        clPrincipal = findViewById(R.id.clPrincipal);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnLimpar = findViewById(R.id.btnLimpar);
        limpeza();

    }
    public void calcular(View c) {
        float fNota1 = Float.parseFloat(etNota1.getText().toString());
        float fNota2 = Float.parseFloat(etNota2.getText().toString());
        tvMedia.setText("Média: " + String.valueOf((fNota1 + fNota2) / 2));

    }
    public void limpar(View l){
        limpeza();
    }
    public void limpeza(){
        etNota1.setText(null);
        etNota2.setText(null);
        tvMedia.setText(null);
        tvSituacao.setText(null);
        etNota1.requestFocus();
        clPrincipal.setBackgroundColor(Color.parseColor("#FFFFFF"));
        tvMedia.setTextColor(Color.parseColor("#000000"));
    }
}